<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: #f9f9f9;
            text-align: center;
        }

        header {
            background-color: #444;
            color: #fff;
            padding: 20px 0;
            font-size: 1.5rem;
            font-weight: bold;
        }

        h1 {
            font-size: 2.5rem;
            margin: 20px 0;
            color: #333;
        }

        p {
            color: #555;
            font-size: 1rem;
            margin-bottom: 40px;
        }

        .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .service {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.3s ease;
        }

        .service:hover {
            transform: translateY(-5px);
        }

        .service img {
            width: 60px;
            height: 60px;
            margin-bottom: 15px;
        }

        .service h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            color: #333;
        }

        .service p {
            font-size: 1rem;
            color: #555;
            line-height: 1.6;
        }

        footer {
            margin-top: 20px;
            padding: 10px;
            background-color: #444;
            color: #fff;
            font-size: 0.9rem;
        }

        footer a {
            color: #00aaff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>My Services</header>

    <h1>What i Offer</h1>
    <p>Explore the wide range of services i provide to help you achieve your goals.</p>

    <div class="container">
        <div class="service">
            <img src="service1-icon.png" alt="Service 1">
            <h3>Web Development</h3>
            <p>I create responsive and modern websites tailored to your needs.</p>
        </div>

        <div class="service">
            <img src="service2-icon.png" alt="Service 2">
            <h3>Graphic Design</h3>
            <p>My designs are creative and engaging, ensuring a lasting impression.</p>
        </div>

   

        <div class="service">
            <img src="service4-icon.png" alt="Service 3">
            <h3>Digital Marketing</h3>
            <p>Grow your brand with my strategic and results-driven marketing campaigns.</p>
        </div>
    </div>

    <footer>
        <p>&copy; Abel Bekure | <a href="index.php">Home</a></p>
    </footer>
</body>
</html>
