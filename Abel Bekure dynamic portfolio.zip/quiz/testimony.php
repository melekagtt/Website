<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Testimonials</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #ece9e6, #ffffff);
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-height: 100vh;
        }

        header {
            width: 100%;
            padding: 20px;
            background-color: #444;
            color: #fff;
            font-size: 1.5rem;
            font-weight: bold;
            text-align: center;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 2.5rem;
            margin: 20px 0;
        }

        .container {
            max-width: 1200px;
            width: 90%;
            margin: 20px auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .testimonial {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .testimonial img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
        }

        .testimonial h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        .testimonial p {
            font-size: 1rem;
            line-height: 1.5;
            color: #555;
        }

        footer {
            margin-top: 20px;
            padding: 10px;
            background-color: #444;
            color: #fff;
            font-size: 0.9rem;
            text-align: center;
            width: 100%;
        }

        footer a {
            color: #00aaff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>Testimonials</header>

    <h1>What People Say About Me</h1>

    <div class="container">
        <div class="testimonial">
            <img src="person1.jpg" alt="Person 1">
            <h3>Dagem Kassahun</h3>
            <p>"Working with Abel Bekure was an amazing experience. They truly understood my vision and brought it to life!"</p>
        </div>

        <div class="testimonial">
            <img src="person2.jpg" alt="Person 2">
            <h3>Kidus Teayent</h3>
            <p>"Abel Bekure's professionalism and creativity are unmatched. I highly recommend their services!"</p>
        </div>

        <div class="testimonial">
            <img src="person3.jpg" alt="Person 3">
            <h3>Eyob Atnafu</h3>
            <p>"The results were beyond my expectations. Abel Bekure is a true artist and expert in their field."</p>
        </div>

        <div class="testimonial">
            <img src="person4.jpg" alt="Person 4">
            <h3>Abel Yohannes</h3>
            <p>"I couldn't be happier with the outcome. Abel Bekure is simply the best!"</p>
        </div>
    </div>

    <footer>
        <p>&copy; Abel Bekure| <a href="index.php">Home</a></p>
    </footer>
</body>
</html>
