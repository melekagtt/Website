<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Portfolio</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background-color: #f4f4f9;
            color: #333;
        }

        header {
            width: 100%;
            padding: 15px 30px;
            background-color: #333;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .nav-links {
            display: flex;
            gap: 15px;
        }

        .nav-links a {
            color: #fff;
            text-decoration: none;
            font-size: 1rem;
            transition: color 0.3s ease;
        }

        .nav-links a:hover {
            color: #007bff;
        }

        h1 {
            font-size: 2.5rem;
            margin: 20px 0 10px;
        }

        p {
            margin: 10px 0 20px;
            font-size: 1.2rem;
            text-align: center;
        }

        .image-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            overflow: hidden;
            border: 5px solid #007bff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 20px 0;
        }

        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        footer {
            margin-top: 20px;
            font-size: 0.9rem;
        }

        footer a {
            color: #007bff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h2>My Portfolio</h2>
        <nav class="nav-links">
                <ul>
                <a href="about.php">About</a>
                <a href="service.php">Services</a>
                <a href="portfolio.php">Portfolio</a>
                <a href="testimony.php">Testimonials</a>
                <a href="contact.php">Contact</a>
                <a href="faq.php">FAQ</a>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            </ul>
        </nav>
    </header>

    <h1>Welcome to My Portfolio</h1>
    <p>Explore my work and projects below</p>

    <div class="image-container">
        <img src="me.jpg" alt="Your Profile Picture">
    </div>

    <footer>
        <p>&copy; Abel Bekure| <a href="contact.php">Contact Me</a></p>
    </footer>
</body>
</html>
