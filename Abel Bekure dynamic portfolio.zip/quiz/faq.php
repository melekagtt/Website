<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            color: #333;
            background-color: #f9f9f9;
        }

        header {
            background-color: #444;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            text-align: center;
        }

        .faq {
            margin-bottom: 20px;
        }

        .faq h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
            color: #0077cc;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .faq h3:hover {
            color: #005fa3;
        }

        .faq p {
            font-size: 1rem;
            color: #555;
            line-height: 1.6;
            display: none;
            margin: 0;
        }

        footer {
            margin-top: 40px;
            padding: 10px;
            background-color: #444;
            color: #fff;
            font-size: 0.9rem;
            text-align: center;
        }

        footer a {
            color: #00aaff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>FAQ</header>

    <div class="container">
        <h1>Frequently Asked Questions</h1>

        <div class="faq">
            <h3>What services do you offer?</h3>
            <p>I offer a wide range of services including web development, graphic design, SEO optimization, and digital marketing. For more details, check my services page.</p>
        </div>

        <div class="faq">
            <h3>How can I contact you?</h3>
            <p>You can contact me and my team through our contact page or send us an email at abelbekure@gmail.com. I am happy to assist you!</p>
        </div>

        <div class="faq">
            <h3>What is your pricing structure?</h3>
            <p>My pricing depends on the scope and requirements of the project. Please get in touch with my  team for a detailed quote tailored to your needs.</p>
        </div>

        <div class="faq">
            <h3>Do you provide ongoing support?</h3>
            <p>Yes, i offer ongoing support and maintenance for all our projects. My goal is to ensure your success even after project delivery.</p>
        </div>
    </div>

    <footer>
        <p>&copy; Abel Bekure | <a href="index.php">Home</a></p>
    </footer>

    <script>
        document.querySelectorAll('.faq h3').forEach(question => {
            question.addEventListener('click', () => {
                const answer = question.nextElementSibling;
                const isVisible = answer.style.display === 'block';
                answer.style.display = isVisible ? 'none' : 'block';
            });
        });
    </script>
</body>
</html>
