<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Me</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            min-height: 100vh;
            background: url('your-image.jpg') no-repeat center center/cover;
            overflow: hidden;
            position: relative;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 1;
        }

        .content {
            position: relative;
            z-index: 2;
            max-width: 800px;
            padding: 20px;
        }

        h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        p {
            font-size: 1.2rem;
            line-height: 1.6;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 1rem;
            color: #fff;
            background: #00aaff;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background: #0077cc;
        }
    </style>
</head>
<body>
    <div class="content">
        <h1>About Me</h1>
        <p>
            Hello! I'm Abel Bekure, a passionate designer and developer who loves creating meaningful and visually stunning digital experiences. With a strong focus on aesthetics and functionality, I aim to bring ideas to life and solve problems creatively.
        </p>
        <a href="index.php" class="btn">Back to Home</a>
    </div>
</body>
</html>
