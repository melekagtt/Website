<?php
require_once 'db.class.php';
$db = new Database();
session_start();
if (!isset($_SESSION['user_email'])) {
    header('Location: login.php');
    exit;
}

$users = $db->fetchAll("SELECT * FROM users");
if (isset($_POST['edit_user'])) {
    $email = htmlspecialchars(trim($_POST['email']));
    $user_to_edit = $db->fetch("SELECT * FROM users WHERE email = ?", [$email]);
    if ($user_to_edit) {
        $first_name = $user_to_edit['first_name'];
        $last_name = $user_to_edit['last_name'];
        $email = $user_to_edit['email'];
    } else {
        $error = "User not found.";
    }
}

if (isset($_POST['update_user'])) {
    $first_name = htmlspecialchars(trim($_POST['first_name']));
    $last_name = htmlspecialchars(trim($_POST['last_name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));  
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $db->fetch("UPDATE users SET first_name = ?, last_name = ?, email = ?, password = ? WHERE email = ?", [$first_name, $last_name, $email, $password, $email]);
        $success = "User updated successfully.";
    }
}


if (isset($_POST['delete_user'])) {
    $email_to_delete = htmlspecialchars(trim($_POST['email']));
    $db->fetch("DELETE FROM users WHERE email = ?", [$email_to_delete]);
    $success = "User deleted successfully.";
}
if (isset($_POST['add_user'])) {
    $first_name = htmlspecialchars(trim($_POST['first_name']));
    $last_name = htmlspecialchars(trim($_POST['last_name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password'])); 
    if (empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $db->fetch("INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)", [$first_name, $last_name, $email, $password]);
        $success = "User added successfully.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="cs.css">
</head>
<body>

    <header>
        <nav>
            <ul>
                
                <li> <a href="index.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <h1>Admin Dashboard</h1>
   

    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <?php if (isset($success)): ?>
        <p style="color: green;"><?php echo $success; ?></p>
    <?php endif; ?>

    <h2>Users</h2>


    <table border="1">
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (isset($users) && is_array($users)): ?>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['first_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
                                <button type="submit" name="edit_user">Edit</button>
                            </form>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="email" value="<?php echo htmlspecialchars($user['email']); ?>">
                                <button type="submit" name="delete_user" onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>


    <?php if (isset($user_to_edit)): ?>
        <h2>Edit User</h2>
        <form method="post" action="">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">

            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" value="<?php echo htmlspecialchars($first_name); ?>" required><br>

            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" value="<?php echo htmlspecialchars($last_name); ?>" required><br>

            <label for="email">Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" readonly required><br>

            <label for="password">Password:</label>
            <input type="password" name="password" required><br>

            <button type="submit" name="update_user">Update User</button>
        </form>
    <?php endif; ?>

  
    <h2>Add New User</h2>
    <form method="post" action="">
        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" required><br>

        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <button type="submit" name="add_user">Add User</button>
    </form>

</body>
</html>
