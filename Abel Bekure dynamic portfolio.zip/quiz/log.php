<?php
require_once 'db.class.php';
$db = new Database();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = htmlspecialchars(trim($_POST['first_name']));
    $last_name = htmlspecialchars(trim($_POST['last_name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));

    if (empty($first_name) || empty($last_name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        $existingUser = $db->fetch("SELECT * FROM users WHERE email = ?", [$email]);

        if ($existingUser) {
            $error = "Email already registered.";
        } else {
            
            
            $db->execute(
                "INSERT INTO users (first_name, last_name, email, password) VALUES (?, ?, ?, ?)",
                [$first_name, $last_name, $email, $password]
            );

            $success = "Registration successful! You can now <a href='login.php'>log in</a>.";
        }
    }
}
?>